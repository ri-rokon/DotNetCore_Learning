﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App11_LINQ3.Models
{
    public class Review
    {
        public int RecipeId { get; set; }
        public string ReviewText { get; set; }
    }
}
