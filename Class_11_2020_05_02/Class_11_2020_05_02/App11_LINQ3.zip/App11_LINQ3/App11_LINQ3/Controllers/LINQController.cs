﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App11_LINQ3.Models;
using Microsoft.AspNetCore.Mvc;

namespace App11_LINQ3.Controllers
{
    public class LINQController : Controller
    {
        public IActionResult Index()
        {
            Recipe[] recipes =
            {
                new Recipe {Id=1, Name="Plain Rice"},
                new Recipe {Id=2, Name="Piza"},
                new Recipe {Id=3, Name="Chotpoti"},
                new Recipe {Id=4, Name="Kabab"}
            };

            Review[] reviews =
            {
                new Review{RecipeId=1, ReviewText="Excellent"},
                new Review{RecipeId=1, ReviewText="Nice"},
                new Review{RecipeId=1, ReviewText="Very Good"},
                new Review{RecipeId=2, ReviewText="Essential"},
                new Review{RecipeId=2, ReviewText="Pretty Good"},
                new Review{RecipeId=3, ReviewText="Not so good..."},
                new Review{RecipeId=3, ReviewText="So So"},
                new Review{RecipeId=4, ReviewText="Most Exciting"},
                new Review{RecipeId=4, ReviewText="Tasty"}
            };

            var reviewresult = from recipe in recipes
                               join review in reviews on recipe.Id equals review.RecipeId
                               into reviewgroup
                               select new
                               {
                                   RecipeName = recipe.Name,
                                   Reviews = reviewgroup
                               };

            List<string> reviewlist = new List<string>();

            foreach (var item in reviewresult)
            {
                reviewlist.Add(item.RecipeName + " :");
                foreach (var r in item.Reviews)
                {
                    reviewlist.Add(r.ReviewText);
                }
            }

            return View(reviewlist);
        }
    }
}