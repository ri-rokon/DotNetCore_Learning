﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using App25_APIConsumer.Models;
using System.Net.Http;
using Newtonsoft.Json;



namespace App25_APIConsumer.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            string url = "https://api.openweathermap.org/data/2.5/weather?q=dhaka&appid=669cb99bff802d564b207d6f568418bd";

            using (var client =new HttpClient())
            {
                var req = client.GetAsync(url);
                var response =await req.Result.Content.ReadAsStringAsync();

                var wo = JsonConvert.DeserializeObject<OurWeather>(response);

                return View(wo);
            }

        }


        //public async Task<IActionResult> Index()
        //{
           
        //    using(var client = new HttpClient())
        //    {
        //        string url = "https://localhost:44303/api/Products";
        //        var req = client.GetAsync(url);
        //        var response =await req.Result.Content.ReadAsStringAsync();
        //        var prodlist = JsonConvert.DeserializeObject<List<Product>>(response);

        //        ViewBag.data = response;

        //        return View(prodlist);
        //    }

        //    //return View(response);
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
