﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace App21_AJAX.Models
{
    public partial class AJAXDBContext : DbContext
    {
        public AJAXDBContext()
        {
        }

        public AJAXDBContext(DbContextOptions<AJAXDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<District> District { get; set; }
        public virtual DbSet<DivList> DivList { get; set; }
        public virtual DbSet<Upazila> Upazila { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                //optionsBuilder.UseSqlServer("Server=DESKTOP-UQ0555I\\SQLEXPRESS;Database=AJAXDB;Trusted_Connection=true;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<District>(entity =>
            {
                entity.ToTable("district");

                entity.Property(e => e.DivListId).HasColumnName("DivListID");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.HasOne(d => d.DivList)
                    .WithMany(p => p.District)
                    .HasForeignKey(d => d.DivListId);
            });

            modelBuilder.Entity<DivList>(entity =>
            {
                entity.ToTable("divList");
            });

            modelBuilder.Entity<Upazila>(entity =>
            {
                entity.Property(e => e.DistrictId).HasColumnName("districtId");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.Upazila)
                    .HasForeignKey(d => d.DistrictId);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
