﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using App10_LINQ2.Models;
using Microsoft.AspNetCore.Mvc;

namespace App10_LINQ2.Controllers
{
    public class LINQController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Example4()
        {
            string[] words = { "cherry", "apple", "blueberry", "date", "pineapple" };

            var sortedwords = from w in words
                              orderby w
                              select w;

            return View(sortedwords);
        }

        public IActionResult Example5()
        {
            List<Person> listperson = new List<Person>()
            {
                new Person{Id=1, Name="Hasan Mahmud", Age=30, Country="Bangladesh"},
                new Person{Id=2, Name="Mahmud Hasan", Age=24, Country="USA"},
                new Person{Id=3, Name="Zafar Ahmed", Age=22, Country="Bangladesh"},
                new Person{Id=4, Name="Tauhid Ahmed", Age=27, Country="UK"},
                new Person{Id=5, Name="Salman Farasi", Age=26, Country="Bangladesh"},
                new Person{Id=6, Name="Abu Taleb", Age=31, Country="Australia"}
            };

            var result = from p in listperson
                         where p.Name.Contains("a") && p.Age.ToString().Contains("2")
                         //where p.Name.EndsWith("a") && p.Age.ToString().Contains("2")
                         select p;


            return View(result);
        }

        public IActionResult Example6()
        {
            int[] numberA = { 0, 2, 4, 5, 6, 8, 9};
            int[] numberB = { 1, 3, 5, 7, 8 };
            
            var pairs = from a in numberA
                        from b in numberB
                        where a < b
                        select new { a, b };

            List<string> result = new List<string>();
            foreach (var item in pairs)
            {
                result.Add(item.a + " : " + item.b);
            }    

            return View(result);
        }

        public IActionResult Example7()
        {
            int[] numbers = { 1, 0, 2, 4, 3, 5, 6, 8, 9, 17, 77, 89, 94, 109, 206, 307};

            var numbergroup = from n in numbers
                              group n by n%5 into g 
                              select new {Remainder = g.Key, Number = g };

            List<string> result = new List<string>();

            foreach (var item in numbergroup)
            {
                result.Add("Group By : " + item.Remainder);
                foreach (var n in item.Number)
                {
                    result.Add(n.ToString());
                }
            }

            return View(result);
        }
    }
}