﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using App12_EFCore.Models;

namespace App12_EFCore.Data
{
    public class AppDBContext : DbContext
    {
        public AppDBContext (DbContextOptions<AppDBContext> options)
            : base(options)
        {
        }

        public DbSet<App12_EFCore.Models.Person> Person { get; set; }

        public DbSet<App12_EFCore.Models.Product> Product { get; set; }

        public DbSet<App12_EFCore.Models.Category> Category { get; set; }
    }
}
