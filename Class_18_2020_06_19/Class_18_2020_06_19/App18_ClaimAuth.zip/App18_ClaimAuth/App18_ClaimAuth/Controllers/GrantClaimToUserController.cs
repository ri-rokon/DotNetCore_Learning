﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Threading.Tasks;
using App18_ClaimAuth.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace App18_ClaimAuth.Controllers
{
    public class GrantClaimToUserController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public GrantClaimToUserController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GrantUser()
        {
            var userlist = _userManager.Users;
            var claimlist = ClaimStore.getAllClaims();

            ViewBag.users = userlist;
            ViewBag.claims = claimlist;

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GrantUser(string uid, string[] clist)
        {
            var userlist = _userManager.Users;
            var claimlist = ClaimStore.getAllClaims();

            ViewBag.users = userlist;
            ViewBag.claims = claimlist;

            if (string.IsNullOrEmpty(uid))
            {
                ViewBag.msg = "No user is selected.";
                return View();
            }
            if (clist.Length<=0)
            {
                ViewBag.msg = "No Permission is selected to grant user.";
                return View();
            }

            var user =await _userManager.FindByIdAsync(uid);

            if (user == null)
            {
                ViewBag.msg = "User does not exist.";
                return View();
            }

            var userclaimlist = await _userManager.GetClaimsAsync(user);
            if (userclaimlist != null)
            {
                await _userManager.RemoveClaimsAsync(user, userclaimlist);
            }

            foreach (var item in clist)
            {
                Claim claim = new Claim(item, item);
                await _userManager.AddClaimAsync(user, claim);
            }

            ViewBag.msg = "User has been granted for selected operations.";
            return View();
        }
    }
}
