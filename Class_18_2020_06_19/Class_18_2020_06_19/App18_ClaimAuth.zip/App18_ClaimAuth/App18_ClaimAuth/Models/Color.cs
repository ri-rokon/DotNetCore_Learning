﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace App18_ClaimAuth.Models
{
    public class Color
    {
        public int Id { get; set; }
        [Required]
        public string ColorName { get; set; }
        public string ColorCode { get; set; }
        public bool IsAvailable { get; set; }
    }
}
