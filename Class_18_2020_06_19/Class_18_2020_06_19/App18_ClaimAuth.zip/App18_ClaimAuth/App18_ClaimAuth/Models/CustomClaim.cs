﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App18_ClaimAuth.Models
{
    public class CustomClaim
    {
        public int Id { get; set; }
        public string CName { get; set; }
        public string CValue { get; set; }
    }
}
