﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using App18_ClaimAuth.Models;

namespace App18_ClaimAuth.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<App18_ClaimAuth.Models.Product> Product { get; set; }
        public DbSet<App18_ClaimAuth.Models.Color> Color { get; set; }
    }
}
