﻿using App18_ClaimAuth.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App18_ClaimAuth
{
    public static class ClaimStore
    {
        private static List<CustomClaim> customClaimList = new List<CustomClaim>()
        {
            new CustomClaim{ CName="Can_Add_Product", CValue="YES"},
            new CustomClaim{ CName="Can_Edit_Product", CValue="YES"},
            new CustomClaim{ CName="Can_Delete_Product", CValue="Can_Delete_Product"},
            new CustomClaim{ CName="Can_Add_Color", CValue="Can_Add_Color"},
            new CustomClaim{ CName="Can_Edit_Color", CValue="Can_Edit_Color"},
            new CustomClaim{ CName="Can_Delete_Color", CValue="YES"}
        };

        public static List<CustomClaim> getAllClaims()
        {
            return customClaimList;
        }
    }
}
