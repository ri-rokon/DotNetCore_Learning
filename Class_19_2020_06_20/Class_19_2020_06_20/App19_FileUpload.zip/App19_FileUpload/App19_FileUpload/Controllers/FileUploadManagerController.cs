﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace App19_FileUpload.Controllers
{
    public class FileUploadManagerController : Controller
    {
        private readonly IWebHostEnvironment _env;

        public FileUploadManagerController(IWebHostEnvironment env)
        {
            _env = env;
        }
        public IActionResult Index()
        {
            string webroot = _env.WebRootPath;
            string folder = "ProductImages";
            string fdir = Path.Combine(webroot, folder);

            string[] files = Directory.GetFiles(fdir);

            List<string> imageFiles = new List<string>();

            foreach (var item in files)
            {
                string ext = Path.GetExtension(item).ToLower();
                if(ext==".jpg" || ext== ".png" || ext == ".jpeg" || ext == ".gif")
                {
                    string imgFile = "/ProductImages/" + Path.GetFileName(item);
                    imageFiles.Add(imgFile);
                }
            }

            return View(imageFiles);
        }

        public IActionResult UploadFile()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile myfile)
        {
            string msg = "";
            string imgFile = "";

            if (myfile != null)
            {
                if (myfile.Length >0) {

                    long fsize = 1024 * 1024;
                    if (myfile.Length > fsize)
                    {
                        ViewBag.msg = "File Size must be less than 1 MB.";
                        ViewBag.link = "https://www.redpro.com.bd";
                        return View();
                    }

                    string webroot = _env.WebRootPath;
                    string folder = "ProductImages";
                    string filename = Path.GetFileName(myfile.FileName);
                    string filetoupload = Path.Combine(webroot, folder, filename);
                    string Ext = Path.GetExtension(myfile.FileName).ToLower();

                    bool IsExist = System.IO.File.Exists(filetoupload);

                    if (IsExist)
                    {
                        ViewBag.msg = "File with same name already exists.";
                        return View();
                    }

                    if (Ext == ".png" || Ext == ".jpeg" || Ext == ".jpg" || Ext == ".gif")
                    {
                        using (var stream = new FileStream(filetoupload, FileMode.Create))
                        {
                            await myfile.CopyToAsync(stream);
                            msg += "File has been uploaded successfully.";
                        }

                        //imgFile = "/ProductImages/" + Path.GetFileName(filetoupload);
                    }
                    else
                    {
                        msg += "File format [" + Ext + "] is not Allowed to upload.";
                    }
                }
                else
                {
                    msg += "File has no content.";
                }
            }
            else
            {
                msg += "File content is null.";
            }

            //ViewBag.image = imgFile;

            ViewBag.allimages = getUploadedImages();
            ViewBag.msg = msg;
            return View();
        }


        private List<string> getUploadedImages()
        {
            string webroot = _env.WebRootPath;
            string folder = "ProductImages";
            string fdir = Path.Combine(webroot, folder);

            string[] files = Directory.GetFiles(fdir);

            List<string> imageFiles = new List<string>();

            foreach (var item in files)
            {
                string ext = Path.GetExtension(item).ToLower();
                if (ext == ".jpg" || ext == ".png" || ext == ".jpeg" || ext == ".gif")
                {
                    string imgFile = "/ProductImages/" + Path.GetFileName(item);
                    imageFiles.Add(imgFile);
                }
            }

            return imageFiles;
        }
    }
}
