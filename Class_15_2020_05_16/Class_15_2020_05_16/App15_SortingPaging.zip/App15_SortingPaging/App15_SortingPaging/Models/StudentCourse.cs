﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App15_SortingPaging.Models
{
    public class StudentCourse
    {
        public int Id { get; set; }
        public int CourseId { get; set; }
        public int StudentId { get; set; }
        public double ResultGradePoint { get; set; }
        public string ResultLetterGrade { get; set; }

        public Student Student { get; set; }
        public Course Course { get; set; }
    }
}
