﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App20_AuthAJAX.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace App20_AuthAJAX.Controllers
{
    public class DataController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public DataController(ApplicationDbContext context, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _context = context;
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public async Task<IActionResult> Index()
        {
            string[] roles = { "Admin", "Manager", "Employee", "Staff", "Accounts", "HR", "ICT" };

            foreach (var item in roles)
            {
               if(! await _roleManager.RoleExistsAsync(item))
                {
                    IdentityRole r = new IdentityRole(item);
                    await _roleManager.CreateAsync(r);
                }
            }

            string[] users = { "admin@test.com", "mgr@test.com", "emp@test.com", "hr@test.com" };

            foreach (var email in users)
            {
                var u = await _userManager.FindByEmailAsync(email);
                if (u==null)
                {
                    IdentityUser usr = new IdentityUser();
                    usr.Email = email;
                    usr.UserName = email;
                    usr.NormalizedEmail = email;
                    //usr.PasswordHash = "Z1@3456";

                    await _userManager.CreateAsync(usr, "Az@123456");
                }
            }

            var uadmin = await _userManager.FindByEmailAsync("admin@test.com");
            if (uadmin != null)
            {
                if(!await _userManager.IsInRoleAsync(uadmin, "Admin"))
                {
                    await _userManager.AddToRoleAsync(uadmin, "Admin");
                }                
            }

            var emp = await _userManager.FindByEmailAsync("emp@test.com");
            if (emp != null)
            {
                if (!await _userManager.IsInRoleAsync(emp, "Employee"))
                {
                    await _userManager.AddToRoleAsync(emp, "Employee");
                }
            }

            var umgr = await _userManager.FindByEmailAsync("mgr@test.com");
            if (umgr != null)
            {
                if (!await _userManager.IsInRoleAsync(umgr, "Manager"))
                {
                    await _userManager.AddToRoleAsync(umgr, "Manager");
                }
            }

            var hr = await _userManager.FindByEmailAsync("hr@test.com");
            if (hr != null)
            {
                if (!await _userManager.IsInRoleAsync(hr, "HR"))
                {
                    await _userManager.AddToRoleAsync(hr, "HR");
                }
            }

            return View();
        }
    }
}
