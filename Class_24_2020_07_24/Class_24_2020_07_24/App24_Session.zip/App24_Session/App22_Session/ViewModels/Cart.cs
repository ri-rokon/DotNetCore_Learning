﻿using App22_Session.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace App22_Session.ViewModels
{
    public class Cart
    {
        public int Id { get; set; }
        public List<Product> Products { get; set; }
    }
}
