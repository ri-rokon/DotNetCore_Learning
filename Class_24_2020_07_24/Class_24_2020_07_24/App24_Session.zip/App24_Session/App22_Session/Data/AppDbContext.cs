﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using App22_Session.Models;
using App22_Session.ViewModels;

namespace App22_Session.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext (DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<App22_Session.Models.Product> Product { get; set; }

        public DbSet<App22_Session.Models.SalesOrder> SalesOrder { get; set; }

        public DbSet<App22_Session.Models.SalesOrderDetail> SalesOrderDetail { get; set; }

        //public DbSet<App22_Session.ViewModels.Cart> Cart { get; set; }
    }
}
