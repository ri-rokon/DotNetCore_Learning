﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using App22_Session.Models;
using Microsoft.AspNetCore.Http;
using App22_Session.Data;
using Microsoft.EntityFrameworkCore;
using App22_Session.ViewModels;

namespace App22_Session.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            //HttpContext.Session.SetString("Course", "Web Application Development in ASP.NET Core MVC");
            var prod = _context.Product;
            return View(prod);
            //return View();
        }

        public IActionResult AddToCart(int id)
        {
            var mycart = HttpContext.Session.GetObject<Cart>("mycart");
            if (mycart == null)
            {
                Cart c = new Cart();
                c.Id = 1;
                List<Product> plist = new List<Product>();
                c.Products = plist;

                Product p1 = _context.Product.FirstOrDefault(x => x.Id == id);
                if (p1 != null)
                {
                    p1.Quantity = 1;
                    c.Products.Add(p1);
                    //HttpContext.Session.SetString("key", "value");
                    HttpContext.Session.SetObject("mycart", c);
                    return RedirectToAction("ShowCart");
                }
                else
                {
                    return RedirectToAction("Index");
                }

            }
            var exp = mycart.Products.FirstOrDefault(x => x.Id == id);
            bool exitem = mycart.Products.FirstOrDefault(x=> x.Id==id) !=null ? true : false;

            if (exitem)
            {
                exp.Quantity += 1;
                HttpContext.Session.SetObject("mycart", mycart);
            }
            else
            {
                var p = _context.Product.FirstOrDefault(x => x.Id == id);
                p.Quantity = 1;
                mycart.Products.Add(p);
                HttpContext.Session.SetObject("mycart", mycart);
            }

            return RedirectToAction("ShowCart");
        }
        public IActionResult ShowCart()
        {
            var mycart = HttpContext.Session.GetObject<Cart>("mycart");
            if (mycart != null)
            {
                List<Product> prodlist = new List<Product>();
                prodlist = mycart.Products;
                return View(prodlist);
            }
            else
            {
                return View();
            }
        }

        public IActionResult RemoveFromCart(int id)
        {
            if (id <= 0)
            {
                return RedirectToAction("ShowCart");
            }
            var mycart = HttpContext.Session.GetObject<Cart>("mycart");
            if (mycart == null)
            {
                return RedirectToAction("ShowCart");
            }
            var exp = mycart.Products.FirstOrDefault(x => x.Id == id);
            bool exitem = mycart.Products.FirstOrDefault(x => x.Id == id) != null ? true : false;

            if (exitem)
            {
                mycart.Products.Remove(exp);
                HttpContext.Session.SetObject("mycart", mycart);
            }

            return RedirectToAction("ShowCart");
        }

        public IActionResult Show()
        {
            var ctitle = HttpContext.Session.GetString("Course");
            ViewBag.ct = ctitle;
            return View();
        }

        public IActionResult Test()
        {
            var ctitle = HttpContext.Session.GetString("Course");
            ViewBag.ct = ctitle;
            return View();
        }

        public IActionResult Course()
        {
            string msg = "";

            if (TempData["msg"] != null)
            {
                msg = TempData["msg"].ToString();
            }
            ViewBag.msg = msg;
            return View();
        }

        [HttpPost]
        public IActionResult Course(string ctitle)
        {
            string msg = "";
            if (!string.IsNullOrEmpty(ctitle))
            {
                HttpContext.Session.SetString("Course", ctitle);
                msg = "Course Title is Set successfully.";
            }
            else
            {
                msg = "Sorry ! Course Title is Empty";
            }

            TempData["msg"] = msg;
            return RedirectToAction("Course");
        }
        public IActionResult Privacy()
        {

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
