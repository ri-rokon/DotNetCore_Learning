﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using App22_Session.Data;
using App22_Session.Models;
using App22_Session.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace App22_Session.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly AppDbContext _context;

        public InvoiceController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var prod = _context.Product.OrderBy(x => x.Name);
            return View(prod);
        }

        public JsonResult getProduct(int id)
        {
            var prod = _context.Product.FirstOrDefault(x => x.Id == id);
            return Json( prod );
        }

        [HttpPost]
        public JsonResult SaveInvoice(string ordno, DateTime orddate, string cname, string caddress, string mobno)
        {
            if (string.IsNullOrEmpty(ordno))
            {
                return Json(new { result = "fail", message = "Order no. cannot be empty or null." });
            }
            if (string.IsNullOrEmpty(cname))
            {
                return Json(new { result = "fail", message = "Customer Name cannot be empty or null." });
            }
            string custaddress = string.IsNullOrEmpty(caddress) ? "-" : caddress;
            string custmobile = string.IsNullOrEmpty(mobno) ? "-" : mobno;

            var myinvoice = HttpContext.Session.GetObject<Cart>("myinvoice");
            if (myinvoice == null)
            {
                return Json(new { result = "fail", message = "Invoice cannot be prepared with empty products." });
            }
            else
            {
                if (myinvoice.Products.Count() <1)
                {
                    return Json(new { result = "fail", message = "Invoice cannot be prepared with empty products." });
                }
                else
                {
                    SalesOrder so = new SalesOrder();
                    so.Address = custaddress;
                    so.CustomerName = cname;
                    so.Discount = 0;
                    so.OrderNo = ordno;
                    so.OrderDate = orddate;
                    so.MobileNo = custmobile;

                    _context.SalesOrder.Add(so);
                    _context.SaveChanges();

                    int soID = so.Id;

                    foreach (var item in myinvoice.Products)
                    {
                        SalesOrderDetail sod = new SalesOrderDetail();
                        sod.ProductId = item.Id;
                        sod.Price = item.Price;
                        sod.Quantity = item.Quantity;
                        sod.SalesOrderId = soID;

                        _context.SalesOrderDetail.Add(sod);
                        _context.SaveChanges();
                    }

                    HttpContext.Session.SetObject("myinvoice", null);

                    return Json(new { result = "ok", message = "Invoice is saved successfully." });
                }
            }
        }
        public JsonResult addProduct(int id, string name, string unit, double price, double quantity)
        {
            if (id <= 0)
            {
                return Json(new { result = "fail", message = "Id cannot be zero." });
            }
            if (string.IsNullOrEmpty(name))
            {
                return Json(new { result = "fail", message = "Product Name cannot be empty or Null." });
            }
            if (string.IsNullOrEmpty(unit))
            {
                return Json(new { result = "fail", message = "Product Unit cannot be empty or Null." });
            }
            if (price <= 0)
            {
                return Json(new { result = "fail", message = "Price cannot be zero." });
            }
            if (quantity <= 0)
            {
                return Json(new { result = "fail", message = "Quantity cannot be zero." });
            }

            var myinvoice = HttpContext.Session.GetObject<Cart>("myinvoice");
            if (myinvoice == null)
            {
                Cart c = new Cart();
                c.Id = 1;
                c.Products = new List<Product>();

                Product p1 =new Product{Id=id, Name=name, Unit=unit, Price=price, Quantity=quantity };
                c.Products.Add(p1);
                HttpContext.Session.SetObject("myinvoice", c);
                return Json(new { result = "ok", message = "Product is added successfully.", products= c.Products });
            }
            var exp = myinvoice.Products.FirstOrDefault(x => x.Id == id);
            bool exitem = exp== null ? false : true;

            if (exitem)
            {
                exp.Quantity = quantity;
                HttpContext.Session.SetObject("myinvoice", myinvoice);
            }
            else
            {
                Product p = new Product { Id = id, Name = name, Unit = unit, Price = price, Quantity = quantity };
                myinvoice.Products.Add(p);
                HttpContext.Session.SetObject("myinvoice", myinvoice);
            }

            return Json(new { result = "ok", message = "Product is added successfully.", products = myinvoice.Products });
        }
    }
}
