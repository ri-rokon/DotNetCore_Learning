﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace App22_Session.Models
{
    public class SalesOrder
    {
        public int Id { get; set; }
        public string OrderNo { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime OrderDate { get; set; }
        public string CustomerName { get; set; }
        public string MobileNo { get; set; }
        public string Address { get; set; }
        public double Discount { get; set; }
        public List<SalesOrderDetail> SalesOrderDetails { get; set; }
    }
}
