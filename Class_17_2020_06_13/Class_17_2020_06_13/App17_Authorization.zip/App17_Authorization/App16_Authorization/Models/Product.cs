﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace App16_Authorization.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Unit { get; set; }
        [Required]
        public double Price { get; set; }

        public int ColorId { get; set; }
        public int SizeId { get; set; }

        public Color Color { get; set; }
        public Size Size { get; set; }
    }
}
